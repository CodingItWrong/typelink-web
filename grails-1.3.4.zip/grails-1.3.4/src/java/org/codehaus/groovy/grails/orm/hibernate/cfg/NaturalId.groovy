package org.codehaus.groovy.grails.orm.hibernate.cfg

/**
 * @author Graeme Rocher
 * @since 1.1
 */
class NaturalId {
    List<String> propertyNames = []
    boolean mutable = false
}
